package com.app.registro;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


import org.json.JSONArray;




public class MainActivity extends AppCompatActivity {

    EditText codigo,nombre,apellido,escuela;
    Button buscar,agregar,editar,eliminar;

    RequestQueue requestQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        codigo=findViewById(R.id.etCodigo);
        nombre=findViewById(R.id.etNombres);
        apellido=findViewById(R.id.etApellidos);
        escuela=findViewById(R.id.etEscuela);

        buscar=findViewById(R.id.btnBuscar);
        agregar=findViewById(R.id.btnAgregar);
        editar=findViewById(R.id.btnEditar);
        eliminar=findViewById(R.id.btnElminiar);



        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ejecutarServicio("https://192.168.1.254:8080/registro_webservice/insertar_alumno.php");
            }
        });

        buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscarAlumno("https://192.168.1.254:8080/registro_webservice/buscar_alumno.php?codigo="+codigo.getText()+"");
            }
        });

        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ejecutarServicio("https://192.168.1.254:8080/registro_webservice/modificar_alumno.php");
            }
        });

        eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eliminarAlumno("https://192.168.1.254:8080/registro_webservice/eliminar_alumno.php");
            }
        });

    }

    //Metodos

    private void ejecutarServicio(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "OPERACION EXISTOSA", Toast.LENGTH_SHORT).show();
            }
        },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            protected Map<String,String> getParams() throws AuthFailureError{
                Map<String, String> parametros=new HashMap<String, String>();
                parametros.put("codigo",codigo.getText().toString());
                parametros.put("nombre",nombre.getText().toString());
                parametros.put("apellido",apellido.getText().toString());
                parametros.put("escuela",escuela.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void buscarAlumno(String URL) {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);
                                nombre.setText(jsonObject.getString("nombres"));
                                apellido.setText(jsonObject.getString("apellidos"));
                                escuela.setText(jsonObject.getString("escuela"));
                            }
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "ERROR DE CONEXION EN LA BASE DE DATOS", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Manejar errores de la solicitud
                    }
                });

        // Añadir la solicitud a la cola de solicitudes
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    private void eliminarAlumno(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "EL ALUMNO FUE ELIMINADO", Toast.LENGTH_SHORT).show();
                limpiarCajas();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String,String> getParams() throws AuthFailureError{
                Map<String,String> parametros=new HashMap<String,String>();

                parametros.put("codigo",codigo.getText().toString());
                return parametros;

            }

        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void limpiarCajas(){
        codigo.setText("");
        nombre.setText("");
        apellido.setText("");
        escuela.setText("");
    }


}

